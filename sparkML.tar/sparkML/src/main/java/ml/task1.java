package ml;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Iterator;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.*;

import scala.Tuple2;
import scala.Tuple2.*;



public class task1 {
    
	public static void main(String[] args) {
        
        // STEP - 1: initilisation
			// Handle input parameters
		String inputDataPath1 = args[0];
		String inputDataPath2 = args[1];
		String outputDataPath = args[2];
        // JavaSparkContext
			//  build a Spark context object
		SparkConf conf = new SparkConf();
		conf.setAppName("assignmnent3_task1");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		
		// STEP - 2: Load data (textFile)
            // 2.1 build function to remove header for input file
		Function2 removeHeader= new Function2<Integer, Iterator<String>, Iterator<String>>(){
		    @Override
		    public Iterator<String> call(Integer ind, Iterator<String> iterator) throws Exception {
		        if(ind==0 && iterator.hasNext()){
		            iterator.next();
		            return iterator;
		        }else
		            return iterator;
		    }
		};
            // 2.2 Load data
                // geoData - > (PatientId, geneId, experssion_value)
                // patientData - > (PatientId, age, gender, postcode, disease, drug_response)
		JavaRDD<String> geoData = sc.textFile(inputDataPath1+"GEO.txt")
				                    .mapPartitionsWithIndex(removeHeader,false);            
	    JavaRDD<String> patientData = sc.textFile(inputDataPath2 + "PatientMetaData.txt")
	    		                        .mapPartitionsWithIndex(removeHeader,false);


		// STEP - 3: Clean the data (filter)
			// input
				// geoData - > (PatientId, geneId, experssion_value)
				// patientData - > (id, age, gender, postcode, disease, drug_response)
			// output
				// patientcount -> (patientId, count)
				// diseasecount - > (PatientId, disease)
			// 3.1 filter entries in patientData
			  	// which have disease in ["breast-cancer", "prostate-cancer", "pancreatic-cancer", "leukemia", "lymphoma"]
	    patientData.filter(s -> 
                            {  String[] values = s.split(",");
                               if (values[4].contains("breast-cancer") || values[4].contains("prostate-cancer")|| values[4].contains("pancreatic-cancer")|| values[4].contains("leukemia")|| values[4].contains("lymphoma") ){
        	                       return true;
                               }else{
        	                       return false;
                               }	
                            });
		// 3.2 filter entries in geoData
			// which have geneID == 42 and expression_value > 1250000
			// and also return output in format Tuple2<String, Integer> 
		JavaPairRDD<String, Integer> patientcount = geoData
		   .filter(s -> {  String[] values = s.split(",");
            if (Integer.parseInt(values[1]) == 42 && Float.parseFloat(values[2])>=1250000f){
               return true;
            }else{
               return false; 
            }	
           }).mapToPair(s ->
		    {  String[] values = s.split(",");

		       return new Tuple2<String, Integer>(values[0],1);
		    }
	    );
		// 3.3 output filtered entries in patientData by "flatMapToPair" function
			// return ouput in format Tuple2<String, String>
		JavaPairRDD<String,String> diseasecount = patientData.flatMapToPair(s ->
		    {  String[] values = s.split(",");
		       int length = values.length;
		       ArrayList<Tuple2<String,String>> results = new ArrayList<Tuple2<String,String>>();
	           if (length == 6){
	            	String[] diseases = values[4].split(" ");
	            	
	            	for (String disease: diseases)
	            	{
	            		
	            		if (disease.contains("breast-cancer") || disease.contains("prostate-cancer")|| disease.contains("pancreatic-cancer")|| disease.contains("leukemia")|| disease.contains("lymphoma") ){
	            			results.add(new Tuple2<String,String>(values[0],disease));
	            		}
	            	}
	           }
	           return results.iterator();
		     }
		);
		

		// STEP - 4: Join/ reduceByKey / mapToPair
			// input
				// patientcount -> (patientId, count)
				// diseasecount - > (id, disease)
			// output
				// swapPair - > (disease, sum_of_counts)
		// 4.1 Join diseasecount and patientcount by "patientId"
		JavaPairRDD<String, Tuple2<String,Integer>> iddiseasecount = diseasecount.join(patientcount);
		// 4.2 reduceByKey 
			// 4.2.1 group by key
			// 4.2.2 then, sum all of the counts
		JavaPairRDD<String, Integer> diseasecountsep = iddiseasecount.values().mapToPair(v->v).reduceByKey((n1,n2) -> n1+ n2);
		// 4.3 mapToPair
			// return the result in format Tuple2<String, Integer> which is (disease, sum_of_counts)              
		JavaPairRDD<Integer, String> swapPair = diseasecountsep.mapToPair(new PairFunction<Tuple2<String, Integer>, Integer, String>() {
	           @Override
	           public Tuple2<Integer, String> call(Tuple2<String, Integer> item) throws Exception {
	               return item.swap();
	           }
	        });
		

		// STEP - 5 : saveAsTextFile 
			// save the result in outputDataPath/task1
		swapPair.coalesce(1).sortByKey(false).map(x -> x._2 + "\t" + x._1).saveAsTextFile(outputDataPath + "task1");
		sc.close();
	}
}
