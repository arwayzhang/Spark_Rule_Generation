package ml;


// STEP-0: import required classes and interfaces

import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.*;
//
import scala.Tuple2;
import scala.Tuple3;

//
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.*;


public class task3 {
  
   public static void main(String[] args) throws Exception {

      	// STEP-1: Initilisation
	  		// Handle input parameters
		String inputDataPath = args[0];
		String outputDataPath = args[1];
		SparkConf conf = new SparkConf();
			// build a spark context object
		conf.setAppName("assignmnent3_task3").set("spark.cores.max","4");
		JavaSparkContext sc = new JavaSparkContext(conf);
      

		// STEP-2: Load data (textFile)
		JavaRDD<String> itemsetData = sc.textFile(inputDataPath);
			// do the transformation: String -> ItemSet
		JavaRDD<ItemSet> patterns = itemsetData.map(new InputtoItemset());
		
		// STEP-3: Mining association rules
			// 3.1 break each a set of geneId down into multiple subsets
				// e.g. {1, 2} -- > {1 , 2} , {1}, {2}
		        //Then the results are like: ({1 , 2} , ({1, 2} , frequency)); ({1} , ({1, 2} , frequency)), ({1 , 2} , ({2} , frequency))

		JavaPairRDD<ArrayList<Integer>,Tuple2<ArrayList<Integer>,Integer>> subpatterns = patterns.flatMapToPair(new SubpatternFunction());
	    
		    // 3.2 group by the sublist
		JavaPairRDD<ArrayList<Integer>,Iterable<Tuple2<ArrayList<Integer>,Integer>>> rules = subpatterns.groupByKey(); 
			
		    // 3.3 calculate confidence value for each sub-itemsets & filter sub-itemsets that do not meet required confidence value
	    JavaPairRDD<Double,Tuple2<ArrayList<Integer>,ArrayList<Integer>>> assocRules = rules.flatMapToPair(new GenerateRules());


		// STEP-4: Save the result 
	    assocRules.sortByKey(false).map(x -> x._2._1 + "\t" + x._2._2 + "\t" + x._1).saveAsTextFile(outputDataPath + "task3");
		sc.close();
}

////All user-defined functions, classes, operators
////Support Functions////////////////////////////////////////////////////////////////

   //Generate sulists and map them into Iterator<Tuple2<ArrayList<Integer>, Tuple2<ArrayList<Integer>,Integer>>>
	public static class SubpatternFunction implements PairFlatMapFunction<ItemSet, ArrayList<Integer>, Tuple2<ArrayList<Integer>,Integer>> {
		
		///Generate all the sublists of a list////////////////////////////
	    public static ArrayList<ArrayList<Integer>> subsets(ArrayList<Integer> a) {
	        if(a == null)
	            return null;
	        Collections.sort(a);
	        ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();        
	        
	        for(int i = 0; i < a.size(); i++){            
	            ArrayList<ArrayList<Integer>> temp = new ArrayList<ArrayList<Integer>>();
	            
	            for(ArrayList<Integer> list : result){
	                temp.add(new ArrayList<Integer>(list));
	            }

	            
	            for(ArrayList<Integer> list : temp){
	                list.add(a.get(i));
	            }
	            ArrayList<Integer> single = new ArrayList<Integer>();
	            single.add(a.get(i));
	            temp.add(single);
	           
	            
	            result.addAll(temp);
	        }
	        result.add(0, new ArrayList<Integer>());

	        Collections.sort(result, new Comparator<ArrayList<Integer>>() {
	            @Override
	            public int compare(ArrayList<Integer> a, ArrayList<Integer> b) {
	                int an = a.size();
	                int bn = b.size();
	                for (int i = 0; i < Math.min(an, bn); i++) {
	                    int cmp = Integer.compare(a.get(i), b.get(i));
	                    if (cmp != 0)
	                        return cmp;
	                }
	                return Integer.compare(a.size(), b.size());
	            }
	        });

	        return result;
	    }
		/////////////////////////////////////
		
		private static final long serialVersionUID = 1L;
		
		public Iterator<Tuple2<ArrayList<Integer>, Tuple2<ArrayList<Integer>,Integer>>> call(ItemSet arg0) throws Exception {
			
			ArrayList<Integer> list = arg0.items;
			
			Collections.sort(list);
			
			Integer frequency = arg0.getNumberOfTransactions();
			
			List<Tuple2<ArrayList<Integer>, Tuple2<ArrayList<Integer>,Integer>>> result = new ArrayList<Tuple2<ArrayList<Integer>, Tuple2<ArrayList<Integer>,Integer>>>();

			result.add(new Tuple2(list, new Tuple2(null,frequency)));
			
            if (list.size() == 1) {
                return result.iterator();
             }
			
           
            ArrayList<ArrayList<Integer>> sublists = subsets(list);
                        
            for(ArrayList<Integer> sublist : sublists){
            	
            	if (sublist.isEmpty() ){
            		
            		continue;
            	}
            	
            	result.add(new Tuple2(sublist, new Tuple2(list, frequency)));
            	
            	
            }

            return result.iterator();
			
			
		}
		
		
		
	}
   
   
   // Map String into ItemSet
   public static class InputtoItemset implements Function<String, ItemSet> {
		
		private static final long serialVersionUID = 1L;
		
		public ItemSet call(String arg0) throws Exception {
			
			
			
			String[] values = arg0.split("\t");
			
			Integer key = Integer.parseInt(values[0]);
   

			
			
			
			ArrayList<Integer> value = new ArrayList<Integer>();
			
			for (int i = 1; i < values.length; i++){
				
				value.add(Integer.parseInt(values[i]));
				
			}
			
			
			Collections.sort(value);
			
			ItemSet newItemSet = new ItemSet(value);
			newItemSet.setNumberOfTransactions(key);
			
			
			return newItemSet;
			
			
		}
		
		
		
	}
   

   //Generate the Rules and cross out the rules with low confidence
   public static class GenerateRules implements PairFlatMapFunction<Tuple2<ArrayList<Integer>,Iterable<Tuple2<ArrayList<Integer>,Integer>>>, Double,Tuple2<ArrayList<Integer>,ArrayList<Integer>>> {
		
		private static final long serialVersionUID = 1L;
		
		public Iterator<Tuple2<Double,Tuple2<ArrayList<Integer>,ArrayList<Integer>>>> call(Tuple2<ArrayList<Integer>,Iterable<Tuple2<ArrayList<Integer>,Integer>>> in) throws Exception {
			
			List<Tuple2<Double,Tuple2<ArrayList<Integer>,ArrayList<Integer>>>> result =
					new ArrayList<Tuple2<Double,Tuple2<ArrayList<Integer>,ArrayList<Integer>>>>();
			
			
			ArrayList<Integer> fromList = in._1;
			
			Iterable<Tuple2<ArrayList<Integer>,Integer>> to = in._2;
			
			ArrayList<Tuple2<ArrayList<Integer>,Integer>> toList = new ArrayList<Tuple2<ArrayList<Integer>,Integer>>();
			
			Tuple2<ArrayList<Integer>,Integer> fromCount = null;
			
            for (Tuple2<ArrayList<Integer>,Integer> t2 : to) {
                // find the "count" object
                if (t2._1 == null) {
                	fromCount = t2;
                }
                else {
                   toList.add(t2);
                }
             }
			
			
            if (toList.isEmpty()) {
                // no output generated, but since Spark does not like null objects, we will fake a null object
                return result.iterator(); // an empty list
             } 
            
            
            
            
            for (Tuple2<ArrayList<Integer>,Integer>  t2 : toList) {
            	if (fromCount!= null && fromCount._2 != null){
                    double confidence = (double) t2._2 / (double) fromCount._2;
                    ArrayList<Integer> t2List = new ArrayList<Integer>(t2._1);
                    t2List.removeAll(fromList);
                    if (t2List.isEmpty() == false && confidence > 0.6){
                    	
                    	result.add(new Tuple2<>(confidence, new Tuple2<>(fromList, t2List)));
                    	
                    }
                          		
            		
            	}

             }
            
            
            return result.iterator();
		
			
		}
	
		
	}
   
   

   //define ItemSet
	public static class ItemSet implements Serializable {
		
		private static final long serialVersionUID = 1L;

		public ArrayList<Integer> items;
		public int numberOfTransactions;

		// empty ItemSet
		public ItemSet() {
			this.items = new ArrayList<>();
			this.numberOfTransactions = 0;
		}

		// ItemSet from an item
		public ItemSet(Integer item) {
			this.items = new ArrayList<>();
			this.items.add(item);
			//Collections.sort(this.items);
			this.numberOfTransactions = 1;
		}

		// ItemSet from list of items
		public ItemSet(ArrayList<Integer> itemList) {
			this.items = itemList;
		}

		public void setNumberOfTransactions(int numberOfTransactions) {
			this.numberOfTransactions = numberOfTransactions;
		}

		public int getNumberOfTransactions() {
			return numberOfTransactions;
		}
		
		
		public String totexting() {
			
			Integer k = numberOfTransactions;
			
			String line = k.toString();
			
			Collections.sort(items);
			
			for (Integer item : items){
				
				line += '\t'+item.toString();
			}
			

			return line;
		}
///////////////////////////////////////////////////////////////////////////////////////
		
	}


}  