package ml;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.Serializable;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.*;
import org.apache.spark.broadcast.*;

import scala.Tuple2;
import scala.Tuple2.*;


public class task2 {
	
	public static void main(String[] args) {
		// STEP 1: Initilisation
			// Handle input parameters
		String inputDataPath1 = args[0];
		String inputDataPath2 = args[1];
		String outputDataPath = args[2];
			// build a spark context object
		SparkConf conf = new SparkConf();
		conf.setAppName("assignmnent3_task2").set("spark.cores.max","4");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		// STEP 2: Load data (textFile)
			// 2.1 build function to remove header for input file
		Function2 removeHeader= new Function2<Integer, Iterator<String>, Iterator<String>>(){
		    @Override
		    public Iterator<String> call(Integer ind, Iterator<String> iterator) throws Exception {
		        if(ind==0 && iterator.hasNext()){
		            iterator.next();
		            return iterator;
		        }else
		            return iterator;
		    }
		};
		// 2.2 Load data
                // geoData - > (PatientId, geneId, experssion_value)
                // patientData - > (id, age, gender, postcode, disease, drug_response)
		JavaRDD<String> geoData = sc.textFile(inputDataPath1+"GEO.txt")
				                    .mapPartitionsWithIndex(removeHeader,false);
	    JavaRDD<String> patientData = sc.textFile(inputDataPath2 + "PatientMetaData.txt")
	    		                        .mapPartitionsWithIndex(removeHeader,false);
		
		// STEP 3: Clean the data (filter)
		// input
				// geoData - > (PatientId, geneId, experssion_value)
				// patientData - > (PatientId, age, gender, postcode, disease, drug_response)
		// output
				// patientgeneid -> (patientId, geneid)
				// cancerpatientcount - > (PatientId, 1)
		// 3.1 filter entries in patientData
			  	// which have disease in ["breast-cancer", "prostate-cancer", "pancreatic-cancer", "leukemia", "lymphoma"]
	    patientData.filter(s -> 
                            {  String[] values = s.split(",");
                               if (values[4].contains("breast-cancer") || values[4].contains("prostate-cancer")|| values[4].contains("pancreatic-cancer")|| values[4].contains("leukemia")|| values[4].contains("lymphoma") ){
        	   
        	                       return true;
        	   
                               }else{
        	   
        	                       return false;
        	   
                               }	
        	
                            });
		
	 
	    // 3.2 set the threshold of minimum support and maximum size of itemsets
	       // here the maximum size is defined as 3
	    
	    long allnum = patientData.distinct().count();
	    long minsupport = allnum*30/100;
	    long maxsize = 3;
	    
	    
	    // 3.3 filter entries in GEO.txt
			// filter rule: expression_value > 1250000
			// return filtered RDD in format Tuple2<String, Integer> -> (PatientId, geneId)
		JavaPairRDD<String, Integer> patientgeneid = geoData
				.filter(s -> {  String[] values = s.split(",");
                if (Float.parseFloat(values[2])>=1250000f){
      	   
                     return true;
                  	   
                }else{
                  	   
                     return false;
    
                }	
                  	
                }).mapToPair(s ->
			    {  String[] values = s.split(",");
			       return new Tuple2<String, Integer>(values[0],Integer.parseInt(values[1]));
			    });
			// return filtered patientData in format Tuple2<String, Integer> -> (PatientId, 1)
		JavaPairRDD<String, Integer> cancerpatientcount = patientData
	            .mapToPair(s ->
			    {  String[] values = s.split(",");
			       return new Tuple2<String, Integer>(values[0],1);
			    });

	    // STEP 4: Join / groupByKey (to cross out the non-cancer geneData)
		// input
				// patientgenid -> (patientId, geneid)
				// cancerpatientcount - > (patientId, 1)
			// output
				// (patientId, geneid)
		// 4.1 Join patientgeneid and cancerpatientcount by "patientId" - > (patientId, (geneid, 1))
	    JavaPairRDD<String, Tuple2<Integer,Integer>> idgeneone = patientgeneid.join(cancerpatientcount);
			// mapToPair
				// return in format Tuple2<String, Integer> - (patientId, geneid)

	    JavaPairRDD<String, Integer> filteredpatientgeneidpair = idgeneone
	    		.mapToPair(s ->{
	    			
	                return new Tuple2<String, Integer>(s._1,s._2._1);
		        			
	    		}
                   
	    		);

	           // return in format Java <Integer> for further use - (geneid)
	    JavaRDD<Integer> filteredpatientgeneid = idgeneone
	    		.map(s ->{
	    			
	                return s._2._1;
		        			
	    		}
                   
	    		);
	    
		// groupByKey(1)
		// group by patientId and put all the geneid in a array for further use -> (patientId, arraylist<geneid>)
	    
	    JavaPairRDD<String, Iterable<Integer>> patientgenes =filteredpatientgeneidpair.groupByKey(1);
	    
		JavaPairRDD<String, ArrayList<Integer>> patientlinkgenes = patientgenes.mapToPair(
				(t)->{
					ArrayList<Integer> vList =  new ArrayList<Integer>();
					for (Integer gene: t._2){
						vList.add(gene);
					}
					Collections.sort(vList);

					return new Tuple2<String, ArrayList<Integer>>(t._1,vList);
				}
				);
	    
		
		// map patientlinkgenes into JavaRDD(arraylist<geneid>) for convenience
		JavaRDD<ArrayList<Integer>> patientlinkgenesarray = patientlinkgenes.map(
				(t)->{
					
					return t._2;
				}
				);
		
		
		// STEP 5: Implement apriori algorithm 
			
		// initialisation about apriori parameters, define itemsize-1 as the initial candidate. (with items whose support > minimum support)
		JavaRDD<ItemSet> initial =filteredpatientgeneid
				.map(new InputMapFunction())
				.groupBy(new ItemSetKeySelector())
				.map(new ItemSetReduceFunction())
				.filter(new ItemSetFrequencyFilterFunction(minsupport));
	    
		// broadcast patientlinkgenesarray for further use
		Broadcast<List<ArrayList<Integer>>> broadcastVar = sc.broadcast(patientlinkgenesarray.collect());
		
		//define initial candidate for iteration
		JavaRDD<ItemSet> candidate = initial;
		
			// iteration
				// generate itemset for (size=1, 2, 3)
				// calculate support, support < minsupport will be crossed out
				// pervious survival itemset continuously goes to next iteration
		for(int i = 0; i < (maxsize-1); i++) {
			
			candidate=candidate.cartesian(initial)
					  .map(new ItemSetCrossFunction())
			          .groupBy(new ItemSetKeySelector())
			          .distinct()
			          .map(new ItemSetReduceFunction())
			          .map(new ItemSetCalculateFrequency(broadcastVar))
			          .filter(new ItemSetFrequencyFilterFunction(minsupport));
			
			
			
		}
	
		
		
		// map candidate (JavaRDD<ItemSet>) to JavaPairRDD<Integer, String> for output
		JavaPairRDD<Integer, String> output = candidate.mapToPair(new OutputtextFunction());
		

		// STEP5: Save the result
		output.coalesce(1).sortByKey(false).map(x -> x._1 + "" + x._2).saveAsTextFile(outputDataPath + "task2");
		sc.close();

	}

	//// All user-defined functions, classes, operators
	////support function/////////////////////////////////////////////////////////////////////////////////
	
	// for convenient output format
	public static class OutputtextFunction implements PairFunction<ItemSet, Integer, String> {
		
		private static final long serialVersionUID = 1L;
		
		public Tuple2<Integer,String> call(ItemSet arg0) throws Exception {
			
			
			Collections.sort(arg0.items);
			
			Integer k = arg0.getNumberOfTransactions();
			
			
			String value = "";
			
			for (Integer item : arg0.items){
				
				value += '\t'+item.toString();
			}
			

			return new Tuple2<Integer, String>(k,value);
			
			
			
		}
		
		
		
	}
	
	
	// map geneid into Itemset
	public static class InputMapFunction implements Function<Integer, ItemSet> {

		private static final long serialVersionUID = 1L;
		
		public ItemSet call(Integer arg0) throws Exception {
			return new ItemSet(arg0);
		}

	}
	
	
	// sort ItemSet and use them as key to group 
	public static class ItemSetKeySelector implements Function<ItemSet, String> {

		private static final long serialVersionUID = 1L;

		public String call(ItemSet arg0) throws Exception {
			String key = null;
			ArrayList<Integer> items = arg0.items;

			Collections.sort(items);

			for (Integer item : items) {
				key += item.toString();
			}
			return key;
		}


	}
	
	
	
	// count the number of ItemSet
	public static class ItemSetReduceFunction implements Function<Tuple2<String,Iterable<ItemSet>>, ItemSet> {

		private static final long serialVersionUID = 1L;

		public ItemSet call(Tuple2<String,Iterable<ItemSet>> arg0) throws Exception {
			
			Integer allnum = 0;
			int count = 0;
			ItemSet newitem = new ItemSet();
			
			for (ItemSet item : arg0._2){
				
				allnum += item.getNumberOfTransactions();
				
				if (count == 0){
					
					newitem =new ItemSet(item.items);
				}
				
				count += 1;
			}
			
			newitem.setNumberOfTransactions(allnum);

			return newitem;
		}

	}
	
	
	// calculate the support of each ItemSet
	public static class ItemSetCalculateFrequency implements Function<ItemSet, ItemSet> {

		private static final long serialVersionUID = 1L;
		
		
		
		private List<ArrayList<Integer>> transactions;
		
		public ItemSetCalculateFrequency(Broadcast<List<ArrayList<Integer>>> transactions) {
			this.transactions = transactions.getValue();
		}
		

		public ItemSet call(ItemSet arg0) throws Exception {


			
			ItemSet out = new ItemSet(arg0.items);
			int numberOfTransactions = 0;

			for (ArrayList<Integer> transaction : this.transactions) {
				if (transaction.containsAll(arg0.items)) {
					numberOfTransactions++;
				}
				
			}
			
			out.setNumberOfTransactions(numberOfTransactions);

			return out;

		}

	}
	
	
	//cross out ItemSet with a support below the minimum threshold
	public static class ItemSetFrequencyFilterFunction implements Function<ItemSet, Boolean> {

		private static final long serialVersionUID = 1L;
		
		private final long minNumberOfTransactions;
		
		public ItemSetFrequencyFilterFunction(long minNumberOfTransactions) {
			this.minNumberOfTransactions = minNumberOfTransactions;
		}

		public Boolean call(ItemSet arg0) throws Exception {
			return arg0.getNumberOfTransactions() >= this.minNumberOfTransactions;
		}

	}
	

	
	// clean the cartesian product and combine them into a new Itemset
	public static class ItemSetCrossFunction implements Function<Tuple2<ItemSet,ItemSet>, ItemSet> {

		private static final long serialVersionUID = 1L;

		

		public ItemSet call(Tuple2<ItemSet,ItemSet> arg0) throws Exception {
			
			// create a new ArrayList of items
			ArrayList<Integer> itemslist = new ArrayList<Integer>(arg0._1.items);

			// only add new items
			for (Integer item : arg0._2.items) {
				if (!itemslist.contains(item)) {
					
					itemslist.add(item);
				}
			}

			// create a new ItemSet
			ItemSet newItemSet = new ItemSet(itemslist);

			newItemSet.setNumberOfTransactions(arg0._1.getNumberOfTransactions());

			return newItemSet;
		}

	}
	
	
	
	
	
	
	/////define ItemSet//////////////////////////////////////////////////////////////////////////////
	public static class ItemSet implements Serializable {
		
		private static final long serialVersionUID = 1L;

		public ArrayList<Integer> items;
		public int numberOfTransactions;

		// empty ItemSet
		public ItemSet() {
			this.items = new ArrayList<>();
			this.numberOfTransactions = 0;
		}

		// ItemSet from an item
		public ItemSet(Integer item) {
			this.items = new ArrayList<>();
			this.items.add(item);
			//Collections.sort(this.items);
			this.numberOfTransactions = 1;
		}

		// ItemSet from list of items
		public ItemSet(ArrayList<Integer> itemList) {
			this.items = itemList;
		}

		public void setNumberOfTransactions(int numberOfTransactions) {
			this.numberOfTransactions = numberOfTransactions;
		}

		public int getNumberOfTransactions() {
			return numberOfTransactions;
		}
		
		
		public String totexting() {
			
			Integer k = numberOfTransactions;
			
			String line = k.toString();
			
			Collections.sort(items);
			
			for (Integer item : items){
				
				line += '\t'+item.toString();
			}
			

			return line;
		}
///////////////////////////////////////////////////////////////////////////////////////
		
	}
	
	
	
	
}








